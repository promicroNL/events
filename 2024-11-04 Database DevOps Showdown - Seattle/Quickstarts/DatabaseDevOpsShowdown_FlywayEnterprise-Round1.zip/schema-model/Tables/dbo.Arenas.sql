CREATE TABLE [dbo].[Arenas]
(
[ArenaID] [int] NOT NULL IDENTITY(1, 1),
[ArenaName] [nvarchar] (100) NULL,
[Location] [nvarchar] (100) NULL,
[Capacity] [int] NULL
)
GO
ALTER TABLE [dbo].[Arenas] ADD CONSTRAINT [PK__Arenas] PRIMARY KEY CLUSTERED ([ArenaID])
GO
