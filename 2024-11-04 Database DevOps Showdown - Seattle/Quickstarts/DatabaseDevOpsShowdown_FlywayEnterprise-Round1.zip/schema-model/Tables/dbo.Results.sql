CREATE TABLE [dbo].[Results]
(
[ResultID] [int] NOT NULL IDENTITY(1, 1),
[GameID] [int] NULL,
[WinnerID] [int] NULL,
[LoserID] [int] NULL,
[WinningMethod] [nvarchar] (20) NULL,
[Round] [int] NULL,
[Time] [time] NULL
)
GO
ALTER TABLE [dbo].[Results] ADD CONSTRAINT [PK__Results] PRIMARY KEY CLUSTERED ([ResultID])
GO
ALTER TABLE [dbo].[Results] ADD CONSTRAINT [FK__Results__GameID] FOREIGN KEY ([GameID]) REFERENCES [dbo].[Games] ([GameID])
GO
ALTER TABLE [dbo].[Results] ADD CONSTRAINT [FK__Results__LoserID] FOREIGN KEY ([LoserID]) REFERENCES [dbo].[Boxers] ([BoxerID])
GO
ALTER TABLE [dbo].[Results] ADD CONSTRAINT [FK__Results__WinnerI] FOREIGN KEY ([WinnerID]) REFERENCES [dbo].[Boxers] ([BoxerID])
GO
