CREATE TABLE [dbo].[Boxers]
(
[BoxerID] [int] NOT NULL IDENTITY(1, 1),
[FirstName] [nvarchar] (50) NULL,
[LastName] [nvarchar] (50) NULL,
[Nationality] [nvarchar] (50) NULL,
[BirthDate] [date] NULL,
[Stance] [nvarchar] (20) NULL,
[WeightClass] [nvarchar] (50) NULL
)
GO
ALTER TABLE [dbo].[Boxers] ADD CONSTRAINT [PK__Boxers] PRIMARY KEY CLUSTERED ([BoxerID])
GO
