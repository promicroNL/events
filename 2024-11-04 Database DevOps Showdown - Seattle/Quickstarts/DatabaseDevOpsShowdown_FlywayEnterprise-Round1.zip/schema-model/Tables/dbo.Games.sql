CREATE TABLE [dbo].[Games]
(
[GameID] [int] NOT NULL IDENTITY(1, 1),
[GameDate] [date] NULL,
[ArenaID] [int] NULL,
[MainEvent] [nvarchar] (100) NULL
)
GO
ALTER TABLE [dbo].[Games] ADD CONSTRAINT [PK__Games] PRIMARY KEY CLUSTERED ([GameID])
GO
ALTER TABLE [dbo].[Games] ADD CONSTRAINT [FK__Games__ArenaID] FOREIGN KEY ([ArenaID]) REFERENCES [dbo].[Arenas] ([ArenaID])
GO
