﻿CREATE TABLE [dbo].[Boxers] (
    [BoxerID]     INT           IDENTITY (1, 1) NOT NULL,
    [FirstName]   NVARCHAR (50) NULL,
    [LastName]    NVARCHAR (50) NULL,
    [Nationality] NVARCHAR (50) NULL,
    [BirthDate]   DATE          NULL,
    [Stance]      NVARCHAR (20) NULL,
    [WeightClass] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([BoxerID] ASC)
);

