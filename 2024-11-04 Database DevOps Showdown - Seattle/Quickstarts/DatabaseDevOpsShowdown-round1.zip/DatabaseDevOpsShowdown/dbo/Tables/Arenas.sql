﻿CREATE TABLE [dbo].[Arenas] (
    [ArenaID]   INT            IDENTITY (1, 1) NOT NULL,
    [ArenaName] NVARCHAR (100) NULL,
    [Location]  NVARCHAR (100) NULL,
    [Capacity]  INT            NULL,
    PRIMARY KEY CLUSTERED ([ArenaID] ASC)
);

