﻿CREATE TABLE [dbo].[Results] (
    [ResultID]      INT           IDENTITY (1, 1) NOT NULL,
    [GameID]        INT           NULL,
    [WinnerID]      INT           NULL,
    [LoserID]       INT           NULL,
    [WinningMethod] NVARCHAR (20) NULL,
    [Round]         INT           NULL,
    [Time]          TIME (7)      NULL,
    PRIMARY KEY CLUSTERED ([ResultID] ASC),
    FOREIGN KEY ([GameID]) REFERENCES [dbo].[Games] ([GameID]),
    FOREIGN KEY ([LoserID]) REFERENCES [dbo].[Boxers] ([BoxerID]),
    FOREIGN KEY ([WinnerID]) REFERENCES [dbo].[Boxers] ([BoxerID])
);

