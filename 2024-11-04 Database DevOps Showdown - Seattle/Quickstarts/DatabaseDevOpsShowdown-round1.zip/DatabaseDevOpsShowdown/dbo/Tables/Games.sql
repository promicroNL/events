﻿CREATE TABLE [dbo].[Games] (
    [GameID]    INT            IDENTITY (1, 1) NOT NULL,
    [GameDate]  DATE           NULL,
    [ArenaID]   INT            NULL,
    [MainEvent] NVARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([GameID] ASC),
    FOREIGN KEY ([ArenaID]) REFERENCES [dbo].[Arenas] ([ArenaID])
);

